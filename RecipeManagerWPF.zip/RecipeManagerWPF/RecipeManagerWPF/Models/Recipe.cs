﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeManagerWPF.Models
{
    // Delegate for handling event when recipe exceeds a certain number of calories
    public delegate void RecipeExceedsCaloriesHandler(Recipe recipe);

    public class Recipe
    {
        private List<Ingredient> originalIngredients; // To store the original state of ingredients

        public string Name { get; set; } // Recipe name
        public List<Ingredient> Ingredients { get; set; } // List of ingredients
        public List<string> Steps { get; set; } // List of steps

        // Event triggered when total calories exceed a threshold
        public event RecipeExceedsCaloriesHandler RecipeExceedsCalories;

        public Recipe()
        {
            Ingredients = new List<Ingredient>(); // Initialize ingredients list
            Steps = new List<string>(); // Initialize steps list
            originalIngredients = new List<Ingredient>(); // Initialize original ingredients list
        }

        // Method to add an ingredient to the recipe
        public void AddIngredient(string name, double quantity, string unit, int calories, string foodGroup)
        {
            var ingredient = new Ingredient { Name = name, Quantity = quantity, Unit = unit, Calories = calories, FoodGroup = foodGroup };
            Ingredients.Add(ingredient); // Add to ingredients list
            originalIngredients.Add(new Ingredient { Name = name, Quantity = quantity, Unit = unit, Calories = calories, FoodGroup = foodGroup }); // Add to original ingredients list

            // Trigger event if total calories exceed 300
            if (Ingredients.Sum(ingredient => ingredient.Calories) > 300)
            {
                RecipeExceedsCalories?.Invoke(this);
            }
        }

        // Method to add a step to the recipe
        public void AddStep(string step) => Steps.Add(step);

        // Method to scale the quantities of all ingredients by a given factor
        public void Scale(double factor) => Ingredients.ForEach(ingredient => ingredient.Quantity *= factor);

        // Method to reset the ingredients to their original quantities
        public void Reset()
        {
            for (int i = 0; i < Ingredients.Count; i++)
            {
                Ingredients[i].Quantity = originalIngredients[i].Quantity;
            }
        }

        // Method to clear all ingredients and steps
        public void Clear()
        {
            Ingredients.Clear();
            Steps.Clear();
        }

        // Property to calculate total calories of the recipe
        public int TotalCalories => Ingredients.Sum(ingredient => ingredient.Calories);
    }
}
