﻿using RecipeManagerWPF.Models;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace RecipeManagerWPF
{
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes; // List to store current recipes displayed
        private List<Recipe> allRecipes; // List to store all recipes for filtering and resetting

        public MainWindow()
        {
            InitializeComponent();
            recipes = new List<Recipe>(); // Initialize the recipes list
            allRecipes = new List<Recipe>(); // Initialize the allRecipes list
            RecipeListBox.SelectionChanged += RecipeListBox_SelectionChanged; // Event handler for recipe selection
        }

        private void AddRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            var addRecipeWindow = new AddRecipeWindow(); // Create a new instance of the AddRecipeWindow
            if (addRecipeWindow.ShowDialog() == true) // Show the AddRecipeWindow as a dialog
            {
                recipes.Add(addRecipeWindow.Recipe); // Add the new recipe to the recipes list
                UpdateRecipeList(); // Update the displayed recipe list
            }
        }

        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            string filterText = FilterTextBox.Text.ToLower(); // Get the filter text in lowercase
            string filterType = (FilterComboBox.SelectedItem as ComboBoxItem)?.Content.ToString(); // Get the selected filter type

            IEnumerable<Recipe> filteredRecipes;

            switch (filterType)
            {
                case "Ingredient":
                    filteredRecipes = allRecipes.Where(r => r.Ingredients.Any(i => i.Name.ToLower().Contains(filterText))); // Filter by ingredient name
                    break;
                case "Food Group":
                    filteredRecipes = allRecipes.Where(r => r.Ingredients.Any(i => i.FoodGroup.ToLower().Contains(filterText))); // Filter by food group
                    break;
                case "Max Calories":
                    if (int.TryParse(filterText, out int maxCalories))
                    {
                        filteredRecipes = allRecipes.Where(r => r.TotalCalories <= maxCalories); // Filter by maximum calories
                    }
                    else
                    {
                        filteredRecipes = allRecipes; // If max calories is not a valid number, show all recipes
                    }
                    break;
                default:
                    filteredRecipes = allRecipes; // If no filter type is selected, show all recipes
                    break;
            }

            RecipeListBox.ItemsSource = filteredRecipes; // Update the displayed recipe list with the filtered recipes
        }

        private void ClearFilterButton_Click(object sender, RoutedEventArgs e)
        {
            FilterTextBox.Clear(); // Clear the filter text box
            FilterComboBox.SelectedItem = null; // Clear the selected item in the filter combo box
            RecipeListBox.ItemsSource = allRecipes; // Reset to display all recipes
        }

        private void RecipeListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (RecipeListBox.SelectedItem is Recipe selectedRecipe) // Check if a recipe is selected
            {
                RecipeNameTextBox.Text = selectedRecipe.Name; // Display the recipe name
                IngredientListBox.ItemsSource = selectedRecipe.Ingredients; // Display the ingredients
                StepListBox.ItemsSource = selectedRecipe.Steps; // Display the steps
                TotalCaloriesTextBlock.Text = selectedRecipe.TotalCalories.ToString(); // Display the total calories
            }
        }

        private void ScaleByHalfButton_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeListBox.SelectedItem is Recipe selectedRecipe) // Check if a recipe is selected
            {
                selectedRecipe.Scale(0.5); // Scale the recipe by 0.5
                RefreshRecipeDetails(selectedRecipe); // Refresh the displayed recipe details
            }
        }

        private void ScaleByTwoButton_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeListBox.SelectedItem is Recipe selectedRecipe) // Check if a recipe is selected
            {
                selectedRecipe.Scale(2); // Scale the recipe by 2
                RefreshRecipeDetails(selectedRecipe); // Refresh the displayed recipe details
            }
        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeListBox.SelectedItem is Recipe selectedRecipe) // Check if a recipe is selected
            {
                selectedRecipe.Reset(); // Reset the recipe to its original state
                RefreshRecipeDetails(selectedRecipe); // Refresh the displayed recipe details
            }
        }

        private void RefreshRecipeDetails(Recipe recipe)
        {
            IngredientListBox.ItemsSource = null; // Clear the ingredient list
            IngredientListBox.ItemsSource = recipe.Ingredients; // Refresh the ingredient list
            TotalCaloriesTextBlock.Text = recipe.TotalCalories.ToString(); // Refresh the total calories display
        }

        private void UpdateRecipeList()
        {
            RecipeListBox.ItemsSource = null; // Clear the recipe list box
            RecipeListBox.ItemsSource = recipes.OrderBy(r => r.Name); // Display the recipes sorted by name

            // Update allRecipes whenever recipes list changes
            allRecipes = recipes.ToList(); // Copy the current recipes to the allRecipes list
        }
    }
}
