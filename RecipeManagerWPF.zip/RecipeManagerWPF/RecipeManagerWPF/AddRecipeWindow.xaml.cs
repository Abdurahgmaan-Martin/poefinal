﻿using RecipeManagerWPF.Models;
using System.Collections.Generic;
using System.Windows;

namespace RecipeManagerWPF
{
    public partial class AddRecipeWindow : Window
    {
        public Recipe Recipe { get; private set; } // Property to store the recipe being created

        public AddRecipeWindow()
        {
            InitializeComponent();
            Recipe = new Recipe(); // Initialize a new recipe
            IngredientListBox.ItemsSource = Recipe.Ingredients; // Bind the ingredients list to the ListBox
            StepListBox.ItemsSource = Recipe.Steps; // Bind the steps list to the ListBox
        }

        // Event handler for adding an ingredient to the recipe
        private void AddIngredientButton_Click(object sender, RoutedEventArgs e)
        {
            // Parse the quantity and calories inputs
            if (double.TryParse(IngredientQuantityTextBox.Text, out double quantity) &&
                int.TryParse(IngredientCaloriesTextBox.Text, out int calories))
            {
                // Add the ingredient to the recipe
                Recipe.AddIngredient(
                    IngredientNameTextBox.Text,
                    quantity,
                    IngredientUnitTextBox.Text,
                    calories,
                    IngredientFoodGroupTextBox.Text);

                IngredientListBox.Items.Refresh(); // Refresh the ListBox to display the new ingredient
                ClearIngredientInputs(); // Clear the input fields
            }
            else
            {
                MessageBox.Show("Invalid quantity or calories. Please enter valid numbers."); // Show error message for invalid input
            }
        }

        // Event handler for adding a step to the recipe
        private void AddStepButton_Click(object sender, RoutedEventArgs e)
        {
            Recipe.AddStep(StepTextBox.Text); // Add the step to the recipe
            StepListBox.Items.Refresh(); // Refresh the ListBox to display the new step
            StepTextBox.Clear(); // Clear the step input field
        }

        // Event handler for saving the recipe
        private void SaveRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            Recipe.Name = RecipeNameTextBox.Text; // Set the recipe name
            this.DialogResult = true; // Set the dialog result to true
            this.Close(); // Close the window
        }

        // Method to clear the ingredient input fields
        private void ClearIngredientInputs()
        {
            IngredientNameTextBox.Clear();
            IngredientQuantityTextBox.Clear();
            IngredientUnitTextBox.Clear();
            IngredientCaloriesTextBox.Clear();
            IngredientFoodGroupTextBox.Clear();
        }
    }
}
